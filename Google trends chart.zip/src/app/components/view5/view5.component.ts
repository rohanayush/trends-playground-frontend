import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view5',
  templateUrl: './view5.component.html',
  styleUrls: ['./view5.component.css']
})
export class View5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
